//: [Previous](@previous)

//:# Case 2
//:## Dependency Injection
class Size{
    var height:Double = 10
    var width:Double = 12
    init(height:Double, width:Double){
        self.height = height
        self.width = width
    }
}

class Pizza{
    var size:Size
    init(size:Size){
        self.size = size
    }
    func area()-> Double{
        (size.height)  * (size.width)
    }
}

let sizeModel = Size(height: 12, width: 12)
let pizza = Pizza(size:sizeModel)
let pizza2 = Pizza(size:sizeModel)
//pizza.size =
pizza.area()
pizza2.size.width = 8
pizza.area()
